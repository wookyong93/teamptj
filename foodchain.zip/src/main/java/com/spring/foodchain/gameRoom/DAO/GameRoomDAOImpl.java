package com.spring.foodchain.gameRoom.DAO;

import org.springframework.stereotype.Repository;

@Repository
public class GameRoomDAOImpl implements GameRoomDAO{

}
