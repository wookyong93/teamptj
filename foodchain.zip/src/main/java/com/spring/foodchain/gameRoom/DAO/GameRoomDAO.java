package com.spring.foodchain.gameRoom.DAO;

public interface GameRoomDAO {

}
