package com.spring.foodchain.gameRoom.service;

public interface GameRoomService {

}
