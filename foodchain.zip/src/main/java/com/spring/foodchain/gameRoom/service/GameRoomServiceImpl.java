package com.spring.foodchain.gameRoom.service;

import org.springframework.stereotype.Repository;

@Repository
public class GameRoomServiceImpl implements GameRoomService{

}
