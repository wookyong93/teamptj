package com.spring.foodchain.animal.dao;

public interface AnimalDAO {

	public int rankComparison(String animal);
	public boolean skyOk(String animal);
	
}
