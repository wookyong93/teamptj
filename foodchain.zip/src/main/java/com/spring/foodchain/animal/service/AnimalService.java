package com.spring.foodchain.animal.service;

import com.spring.foodchain.animal.vo.RoleVO;

public interface AnimalService {

	public int rankComparison(String animal);
	public boolean skyOk(String animal);
	
}
